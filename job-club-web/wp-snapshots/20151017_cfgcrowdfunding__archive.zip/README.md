# City Tech Crowdfunding #

Let the fun begin )))

### Setup in www directory of WAMP ###

* cd <LOCAL WAMP WWW DIRECTORY>
* git clone https://<YOUR USERNAME>@bitbucket.org/ctcf/crowdfunding.git

### Development Process ###

* Please use branches for commits
* Merge after branch is success/accepted
* Use issue tracking to let everyone know what you are working on

### MYSQL Defaults ###

* DB: wpctcf
* User: wpctcf
* Passwd: <pm me>