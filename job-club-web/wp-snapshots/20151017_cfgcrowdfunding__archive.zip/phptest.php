<?php

phpinfo();

?>


